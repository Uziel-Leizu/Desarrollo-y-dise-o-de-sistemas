package API;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class Infos extends HttpServlet {

    private PrintWriter out;

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        out = response.getWriter();
        int cont=0;
        //System.out.println("Hola estoy empezando las prguntas");
        response.setContentType("application/json");
        response.addHeader("Access-Control-Allow-Origin", "*");
        String id = request.getParameter("id");
//        System.out.println(id);
        StringBuilder json = new StringBuilder();
        json.append("[");
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection db = DriverManager.getConnection("jdbc:mysql://localhost/crudjson", "root", "rootroot");
            //System.out.println("Hola estoy en preguntas");
            Statement s = db.createStatement();
            ResultSet rs = s.executeQuery("select * from tablajson where id="+id+";");
            while (rs.next()) {
                String cadena = rs.getString("columnajson");
//                System.out.println(cadena);
                json.append(cadena);
                json.append(",");
            }
            
        } catch (Exception e) {
            e.printStackTrace();
        }
        int i = json.length();
//        System.out.println(i);
//        for(i=0;i < json.length();i++){
//            System.out.print(json.charAt(i));
//        }
        json.deleteCharAt(i-1);
        json.append("]");
//        System.out.println(json.toString());
        out.write(json.toString());
    }

}