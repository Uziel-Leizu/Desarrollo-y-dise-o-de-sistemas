package API;

import java.io.IOException;
import java.io.PrintWriter;
import static java.lang.Math.sqrt;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class Calculadora extends HttpServlet {

    private PrintWriter out;

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        out = response.getWriter();
        //System.out.println("Hola estoy empezando la calculadora");
        response.setContentType("application/json");
        response.addHeader("Access-Control-Allow-Origin", "*");

        //Punto A
        String X1 = request.getParameter("x1");
        String Y1 = request.getParameter("y1");
        //Punto B
        String X2 = request.getParameter("x2");
        String Y2 = request.getParameter("y2");
        //Punto C
        String X3 = request.getParameter("x3");
        String Y3 = request.getParameter("y3");
        //id
        String id = request.getParameter("id");
        System.out.println("recibimos id: "+id);
        //comprobacion de conexion
        System.out.println("Hemos recibido X= "+X1+" "+X2+" "+X3);
        System.out.println("Hemos recibido Y= "+Y1+" "+Y2+" "+Y3);
        float inx1 = Float.parseFloat(X1);
        float iny1 = Float.parseFloat(Y1);
        float inx2 = Float.parseFloat(X2);
        float iny2 = Float.parseFloat(Y2);
        float inx3 = Float.parseFloat(X3);
        float iny3 = Float.parseFloat(Y3);
        if ((inx1 == inx2 && iny1 == iny2) || (inx2 == inx3 && iny2 == iny3) || (inx1 == inx3 && iny1 == iny3)) {
            //System.out.println("Hola entramos al error de los puntos");
            out.write(devolverJSONError());
        } else {
            this.CalEq(inx1, iny1, inx2, iny2, inx3, iny3,id);
        }
    }

    private String CalEq(float x1, float y1, float x2, float y2, float x3, float y3,String cid) {
        //System.out.println("Hola, Estamos en la calculadora funcion CalEq");
        float D = 0;
        float E = 0;
        float F = 0;
        float CentroH = 0;
        float CentroK = 0;
        double Radio = 0;
        float Delta = 0;
        float DeltaD = 0;
        float DeltaE = 0;
        float DeltaF = 0;
        float Mul1 = 0;
        float Mul2 = 0;
        float Mul3 = 0;
        float Mul4 = 0;
        float Mul5 = 0;
        float Mul6 = 0;
        float D1 = x1;
        float D2 = x2;
        float D3 = x3;
        float E1 = y1;
        float E2 = y2;
        float E3 = y3;
        float F1 = 1;
        float F2 = 1;
        float F3 = 1;
        float R1 = -((x1 * x1) + (y1 * y1));
        float R2 = -((x2 * x2) + (y2 * y2));
        float R3 = -((x3 * x3) + (y3 * y3));
//        System.out.println("Ecuacion 1 = "+D1+"D + "+E1+"E + "+F1+"F = "+R1);
//        System.out.println("Ecuacion 2 = "+D2+"D + "+E2+"E + "+F2+"F = "+R2);
//        System.out.println("Ecuacion 3 = "+D3+"D + "+E3+"E + "+F3+"F = "+R3);
        //Arriba a abajo
        Mul1 = D1 * E2 * F3;
        Mul2 = D2 * E3 * F1;
        Mul3 = D3 * E1 * F2;
        //Abajo a arriba
        Mul4 = D2 * E1 * F3;
        Mul5 = D1 * E3 * F2;
        Mul6 = D3 * E2 * F1;
        //Sacando delta
        Delta = (Mul1 + Mul2 + Mul3) - (Mul4 + Mul5 + Mul6);
//        System.out.println("Valor de Delta= "+Delta);
        //DELTA D
        //Arriba a abajo
        Mul1 = R1 * E2 * F3;
        Mul2 = R2 * E3 * F1;
        Mul3 = R3 * E1 * F2;
        //Abajo a arriba
        Mul4 = R2 * E1 * F3;
        Mul5 = R1 * E3 * F2;
        Mul6 = R3 * E2 * F1;
        //Sacando Delta D
        DeltaD = (Mul1 + Mul2 + Mul3) - (Mul4 + Mul5 + Mul6);
//        System.out.println("Valor de DeltaD= "+DeltaD);
        //DELTA E
        //Arriba a abajo
        Mul1 = D1 * R2 * F3;
        Mul2 = D2 * R3 * F1;
        Mul3 = D3 * R1 * F2;
        //Abajo a arriba
        Mul4 = D2 * R1 * F3;
        Mul5 = D1 * R3 * F2;
        Mul6 = D3 * R2 * F1;
        //Sacando Delta D
        DeltaE = (Mul1 + Mul2 + Mul3) - (Mul4 + Mul5 + Mul6);
//        System.out.println("Valor de DeltaE= "+DeltaE);
        //DELTA F
        //Arriba a abajo
        Mul1 = D1 * E2 * R3;
        Mul2 = D2 * E3 * R1;
        Mul3 = D3 * E1 * R2;
        //Abajo a arriba
        Mul4 = D2 * E1 * R3;
        Mul5 = D1 * E3 * R2;
        Mul6 = D3 * E2 * R1;
        //Sacando Delta D
        DeltaF = (Mul1 + Mul2 + Mul3) - (Mul4 + Mul5 + Mul6);
//        System.out.println("Valor de DeltaF= "+DeltaF);
        //Cambiamos los valores de D, E y F
        D = DeltaD / Delta;
        E = DeltaE / Delta;
        F = DeltaF / Delta;
        //System.out.println("D= " + D + " E= " + E + " F= " + F);
//        System.out.println("Ecuacion general:");
//        System.out.println("x^2 + y^2 + "+D+"x + "+E+"y + "+F+" = 0");
        String EqG = "x^2 + y^2 + " + D + "x + " + E + "y + " + F + " = 0";
        //Calcular Centro y Radio
        CentroH = -(D / 2);
        CentroK = -(E / 2);
        Radio = sqrt(((D * D) / 4) + ((E * E) / 4) - F);
//        System.out.println("Centro: ("+CentroH+","+CentroK+")");
//        System.out.println("Radio: "+Radio);
        if (D == Double.POSITIVE_INFINITY || E == Double.POSITIVE_INFINITY || F == Double.POSITIVE_INFINITY || D == Double.NEGATIVE_INFINITY || E == Double.NEGATIVE_INFINITY || F == Double.NEGATIVE_INFINITY) {
            out.write(devolverJSONErrorInf());
        } else {
            if(cid==""){
            try {
                DB bd = new DB();
                bd.setConnection("com.mysql.cj.jdbc.Driver", "jdbc:mysql://localhost/crudjson");
                StringBuilder json = new StringBuilder();
                bd.executeUpdate("insert into tablajson(columnajson) values('{}')");
                ResultSet rs = bd.executeQuery("Select * from tablajson");
                int id = 0;
                while (rs.next()) {
                    id = rs.getInt("id");
                }
                String cadSal = ("'{\"id\": \"" + id + "\",\"pregunta\": \"Circulo por los puntos (" + D1 + "," + E1 + ") (" + D2 + "," + E2 + ") (" + D3 + "," + E3 + ")\",\"Ecuaciongeneral\": \"" + EqG + "\",\"Centro\": \"(" + CentroH + "," + CentroK + ")\",\"Radio\": \"" + Radio + "\",\"x1\": \"" + D1 + "\",\"y1\": \"" + E1 + "\",\"x2\": \"" + D2 + "\",\"y2\": \"" + E2 + "\",\"x3\": \"" + D3 + "\",\"y3\": \"" + E3 + "\",\"cx\": \"" + CentroH + "\",\"cy\": \"" + CentroK + "\"}'");
                bd.executeUpdate("UPDATE tablajson SET columnajson = " + cadSal + " WHERE id = " + id + ";");
                out.write(devolverJSON(id + ""));
            } catch (Exception e) {
                e.printStackTrace();
            }
            }else{
                try {
                DB bd = new DB();
                bd.setConnection("com.mysql.cj.jdbc.Driver", "jdbc:mysql://localhost/crudjson");
                int id = Integer.parseInt(cid);
                String cadSal = ("'{\"id\": \"" + id + "\",\"pregunta\": \"Circulo por los puntos (" + D1 + "," + E1 + ") (" + D2 + "," + E2 + ") (" + D3 + "," + E3 + ")\",\"Ecuaciongeneral\": \"" + EqG + "\",\"Centro\": \"(" + CentroH + "," + CentroK + ")\",\"Radio\": \"" + Radio + "\",\"x1\": \"" + D1 + "\",\"y1\": \"" + E1 + "\",\"x2\": \"" + D2 + "\",\"y2\": \"" + E2 + "\",\"x3\": \"" + D3 + "\",\"y3\": \"" + E3 + "\",\"cx\": \"" + CentroH + "\",\"cy\": \"" + CentroK + "\"}'");
                bd.executeUpdate("UPDATE tablajson SET columnajson = " + cadSal + " WHERE id = " + id + ";");
                out.write(devolverJSON(id + ""));
            } catch (Exception e) {
                e.printStackTrace();
            }
            }
        }
        return "hola";
    }

    private String devolverJSON(String id) {
        StringBuilder json = new StringBuilder();

        json.append("[");
        json.append("{");
        json.append(jsonValue("x1", id));
        json.append("}");
        json.append("]");
        return json.toString();
    }

    private String devolverJSONError() {
        //System.out.println("Estamos en errorjson");
        StringBuilder json = new StringBuilder();
        json.append("[");
        json.append("{");
        json.append(jsonValue("x1", "error"));
        json.append("}");
        json.append("]");
        return json.toString();
    }

    private String devolverJSONErrorInf() {
        //System.out.println("Estamos en errorjson");
        StringBuilder json = new StringBuilder();
        json.append("[");
        json.append("{");
        json.append(jsonValue("x1", "infinito"));
        json.append("}");
        json.append("]");
        return json.toString();
    }

    private String jsonValue(String key, Object value) {
        return new StringBuilder()
                .append("\"")
                .append(key)
                .append("\" : \"")
                .append(value)
                .append("\"")
                .toString();
    }
}
