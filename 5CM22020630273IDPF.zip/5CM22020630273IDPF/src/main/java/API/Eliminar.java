package API;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class Eliminar extends HttpServlet {

    private PrintWriter out;

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        out = response.getWriter();
        int cont=0;
        //System.out.println("Hola estoy empezando las prguntas");
        response.setContentType("application/json");
        response.addHeader("Access-Control-Allow-Origin", "*");
        String id = request.getParameter("id");
        //System.out.println("estoy en eliminar este es el id: "+id);
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection db = DriverManager.getConnection("jdbc:mysql://localhost/crudjson", "root", "rootroot");
            //System.out.println("Hola estoy en preguntas");
            Statement s = db.createStatement();
            s.executeUpdate("delete from tablajson where id="+id+";");
            
        } catch (Exception e) {
            e.printStackTrace();
        }

//        System.out.println(i);
//        for(i=0;i < json.length();i++){
//            System.out.print(json.charAt(i));
//        }
        
        
//        System.out.println(json.toString());
        out.write(devolverJSON(""));
    }
    private String devolverJSON(String id) {
        StringBuilder json = new StringBuilder();
        
        json.append("[");
        json.append("{");
        json.append(jsonValue("x1", id));
        json.append("}");
        json.append("]");
        return json.toString();
    }

    private String devolverJSONError() {
        System.out.println("Estamos en errorjson");
        StringBuilder json = new StringBuilder();
        json.append("[");
        json.append("{");
        json.append(jsonValue("x1", "error"));
        json.append("}");
        json.append("]");
        return json.toString();
    }

    private String jsonValue(String key, Object value) {
        return new StringBuilder()
                .append("\"")
                .append(key)
                .append("\" : \"")
                .append(value)
                .append("\"")
                .toString();
    }

}
