import React from "react";
import { Button, Container, Table, Alert } from "react-bootstrap";
import { Link } from "react-router-dom";
import axios from "axios"; //hacer peticiones ascincronas
import Pregunta from "./pregunta";
import Formulario from "./formulario";
import Cookies from "universal-cookie";

class Home extends React.Component {

    state = {
        data: [],
        showAlert: false,
        alertText: ""
    }

    componentDidMount() {
        axios.get("Preguntas").then(response => { //context pack nombre de la carpeta
            this.setState({ data: response.data });
        }).catch(error => {
            console.info(error);
            this.setState({ showAlert: true, alertText: "ERROR EN LA OBTENCION DE DATOS" }); //error que esta marcando
        })
    }
    cerrarSesion(){
        const cookies = new Cookies();
        cookies.remove("usuario",{path: "/"});
        window.location.href='/Proyecto/';
    }
 

    render() {
        const cookies = new Cookies();
        const { data, showAlert, alertText } = this.state;
        return (
            <Container className="MarginContainer" >
                <h1 className="AlignCenter" > Calculadora de Circulo que pasa por 3 puntos </h1>
                <hr style={{ width: "80%" }} />
                {
                    showAlert ?
                        <Alert variant="danger">
                            {alertText}
                        </Alert>
                        : null
                }
                <p id="Usuario">Usuario: {cookies.get('usuario')}</p>
                <Button variant="info" style={{ margin: "12px" }}>
                    <Link to="/Proyecto/formulario" className="CustomLink">Añadir nueva pregunta</Link>
                </Button>
                <Button variant="danger" style={{ margin: "12px" }} onClick={()=>this.cerrarSesion()}>
                    Cerrar sesion
                </Button>
                <Table striped bordered >
                    <thead>
                        <tr>
                            <th>Pregunta</th>
                            <th>Acciones</th>
                        </tr>
                    </thead>
                    <tbody>
                        {
                            data.map(pregunta => {
                                return <Pregunta {...pregunta} />
                                                // ^operador de propagacion
                            })
                        }
                    </tbody>
                </Table>
            </Container>
        )
    }

}

export default Home;