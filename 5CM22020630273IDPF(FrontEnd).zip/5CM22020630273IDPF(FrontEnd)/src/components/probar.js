import React from "react";
import { Button, Container } from "react-bootstrap";
import Form from 'react-bootstrap/Form';
import FormCheck from 'react-bootstrap/FormCheck';
import axios from "axios";

class Probar extends React.Component {

    state = {
        id: "",
        pregunta: "",
        respuesta: "",
        drags: [],
        targets: []
    }

    componentDidMount() {
        const qId = new URLSearchParams(window.location.search).get("id");
        if (qId) {
            axios.get("Infos?id=" + qId).then(response => {
                const question = response.data[0];
                this.setState({ ...question });
            }).catch(error => {
                console.info(error);
                alert("Ha ocurrido un error");
            });
        }
    }

    validarRes(id){
        if(document.getElementById('inline-radio-2').checked & document.getElementById('inline-radio2-1').checked){
            alert("Respuesta correcta");
        }else{
            alert("Hay una o mas respuestas incorrectas");
        }
    }

    render() {
        const {id, pregunta, Ecuaciongeneral, Centro, Radio, x1, x2, x3, y1, y2, y3, cx, cy } = this.state;
        return (
            <Container className="MarginContainer">
                <h3>Responda la siguente pregunta</h3>
                <p>Pregunta: {pregunta}</p>
                <Form>
                    <div key="inline-radio" className="mb-3">
                        <p>¿Donde se hubica el centro de este circulo?</p>
                        <Form.Check
                            inline
                            label={`(${cx-(-2)},${cy-(-1)})`}
                            value="false"
                            name="group1"
                            type="radio"
                            id="inline-radio-1"
                        />
                        <Form.Check
                            inline
                            label={`(${cx},${cy})`}
                            value="true"
                            name="group1"
                            type="radio"
                            id="inline-radio-2"
                        />
                        <Form.Check
                            inline
                            label={`(${cx-4},${cy-2})`}
                            value="false"
                            name="group1"
                            type="radio"
                            id="inline-radio-3"
                        />
                    </div>
                    <div key="inline-radio2" className="mb-3">
                        <p>¿Cual es el radio de este circulo?</p>
                        <Form.Check
                            inline
                            label={`${Radio}`}
                            value="true"
                            name="group2"
                            type="radio"
                            id="inline-radio2-1"
                        />
                        <Form.Check
                            inline
                            label={`${Radio-(-4)}`}
                            value="false"
                            name="group2"
                            type="radio"
                            id="inline-radio2-2"
                        />
                        <Form.Check
                            inline
                            label={`${Radio-3}`}
                            value="false"
                            name="group2"
                            type="radio"
                            id="inline-radio2-3"
                        />
                    </div>
                </Form>
                <Button variant="success" onClick={() => this.validarRes(id)}>
                    Submit
                </Button>
                <Button id="espacio" variant="secondary" onClick={() => window.location.href = "/Proyecto/"}>
                    Regresar
                </Button>
                <br></br>
                <svg width='1000' height='1000'>
                    <line x1="0" y1="500" x2="1000" y2="500" stroke="black"></line>
                    <line x1="500" y1="0" x2="500" y2="1000" stroke="black"></line>
                    {/*circulo generado*/}
                    <circle cx={500 + (cx * 25)} cy={500 - (cy * 25)} r={(Radio * 25)} fill="none" stroke="black" strokeWidth="2"></circle>
                    {/*circulo centro punto*/}
                    <circle cx={500 + (cx * 25)} cy={500 - (cy * 25)} r="5" fill="red"></circle>
                    {/*circulo punto 1*/}
                    <circle cx={500 + (x1 * 25)} cy={500 - (y1 * 25)} r="5" fill="blue"></circle>
                    {/*circulo punto 2*/}
                    <circle cx={500 + (x2 * 25)} cy={500 - (y2 * 25)} r="5" fill="green"></circle>
                    {/*circulo punto 3*/}
                    <circle cx={500 + (x3 * 25)} cy={500 - (y3 * 25)} r="5" fill="cyan"></circle>
                </svg>

            </Container>
        )
    }
}

export default Probar;