import React from "react";
import Form from "react-bootstrap/Form"
import Button from "react-bootstrap/Button"
import $ from "jquery"
import { browserHistory } from "react-router";
import ReactDOM from "react-dom"
import Home from "./home"
import Cookies from "universal-cookie";

class Login extends React.Component {

  state = {
    val: false,
  }
  componentDidMount() {
    const cookies = new Cookies();
    if (cookies.get("usuario") != undefined) {
      this.state.val = true;
      this.forceUpdate();
    }
  }
  cambiar = () => {
    this.setState((state) => ({
      val: true,
      comp: <Home></Home>
    }))
  }

  validar = (usuario, password) => {
    var datos = {
      User: usuario,
      password: password
    }

    $.get("Login", datos, (resultado) => {
      if (resultado[0].usuario != "error") {
        this.state.val = true;

        const cookies = new Cookies();
        //cookies.remove("usuario",{path: "/"});
        //alert("cookies? "+cookies.get("usuario"));
        cookies.set("usuario", resultado[0].usuario, { path: '/' });
        //window.location.href='/Proyecto/home';
        //alert("Bienvenido "+cookies.get("usuario"));
        this.forceUpdate();
      } else {
        alert("USUARIO NO REGISTRADO");
      }

    })

  }
  render() {
    const styles = {
      padding: '5px',
      backgroundImage:
        "url(https://www.aprendematematicas.org.mx/wp-content/ql-cache/quicklatex.com-7b27d1dfacfb4bab14943dba97083a34_l3.png)",
      height: "1080px",
    }
    const qId = (new URLSearchParams(window.location.search).get("val") == "true") ? true : false;
    const undiv = <div className="center-container" style={styles} id="equis">
      <div className="FondoLogin" id="centrar">
        <h1 className="AlignCenter" > LOGIN </h1>

        <div class="FormLogin" id="centrar">
          <div class="form-group">
            <label class="form-label" for="User">Usuario</label>
            <input placeholder="Ingrese el usuario" type="text" id="User" class="form-control" />
          </div>
          <div class="form-group">
            <label class="form-label" for="password">Password</label>
            <input placeholder="Ingrese su contraseña" type="password" id="password" class="form-control" />
          </div>
          <button className="btn btn-primary" onClick={() => this.validar(document.getElementById("User").value, document.getElementById("password").value)}>
            Submit
          </button>
        </div>
      </div>

    </div>
    const esValido = (this.state.val) || qId ? <Home></Home> : undiv
    return (
      <div>
        {esValido}
        {console.log(esValido)}
      </div>
    )
  }
}
export default Login;