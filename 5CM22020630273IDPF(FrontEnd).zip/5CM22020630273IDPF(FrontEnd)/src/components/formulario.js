import React from "react";
import Form from "react-bootstrap/Form"
import Button from "react-bootstrap/Button"
import $ from "jquery"
import { browserHistory } from "react-router";
import ReactDOM from "react-dom"
import Home from "./home"
import axios from "axios";
import Cookies from "universal-cookie";

class Formulario extends React.Component {
    state = {
        val: false,
        id: 0
    }

    componentDidMount() {
        const qId = new URLSearchParams(window.location.search).get("id");
    }

    validar = (vX1, vY1, vX2, vY2, vX3, vY3,qId) => {
        var datos = {
            x1: vX1,
            y1: vY1,
            x2: vX2,
            y2: vY2,
            x3: vX3,
            y3: vY3,
            id: qId,
        }
        $.get("Calculadora", datos, (resultado) => {
            this.state.id = resultado[0].x1;
            if (this.state.id == "error") {
                //this.state.val = true;
                alert("Hay 2 o mas puntos iguales");
            } else if (this.state.id == "infinito") {
                alert("El calculo devuelve infinito");
            } else {
                this.redir(this.state.id);
            }

        })
    }
    redir = (id) => {
        window.location.href = `/Proyecto/`;
    }

    render() {
        const qId = new URLSearchParams(window.location.search).get("id");
        return (
            
            <div>
                <h1 className="AlignCenter">Agregar puntos</h1>
                <p></p>
                <div class="FormLogin" id="centrar">
                    <div class="form-group">
                        <label class="form-label">Entrada del Primer punto</label>
                        <div>
                            (<input placeholder="X" type="text" id="X1" class="CuadroVar"></input>)
                            (<input placeholder="Y" type="text" id="Y1" class="CuadroVar"></input>)
                        </div>
                        <label class="form-label">Entrada del Segundo punto</label>
                        <div>
                            (<input placeholder="X" type="text" id="X2" class="CuadroVar"></input>)
                            (<input placeholder="Y" type="text" id="Y2" class="CuadroVar"></input>)
                        </div>
                        <label class="form-label">Entrada del Tercer punto</label>
                        <div>
                            (<input placeholder="X" type="text" id="X3" class="CuadroVar"></input>)
                            (<input placeholder="Y" type="text" id="Y3" class="CuadroVar"></input>)
                        </div>
                    </div>
                    <Button variant="secondary" onClick={() => window.location.href = "/Proyecto/"}>
                        Regresar
                    </Button>
                    <button className="btn btn-primary" id="espacio" onClick={() => this.validar(document.getElementById("X1").value, document.getElementById("Y1").value, document.getElementById("X2").value, document.getElementById("Y2").value, document.getElementById("X3").value, document.getElementById("Y3").value,qId)}>
                        Submit
                    </button>
                </div>
            </div>
        );
    }
}
export default Formulario;