import React from "react";
import { Button, Container } from "react-bootstrap";
import axios from "axios";

class Info extends React.Component {

    state = {
        id: "",
        pregunta: "",
        respuesta: "",
        drags: [],
        targets: []
    }

    componentDidMount() {
        const qId = new URLSearchParams(window.location.search).get("id");
        if (qId) {
            axios.get("Infos?id="+qId).then(response => {
                const question = response.data[0];
                this.setState({ ...question });
            }).catch(error => {
                console.info(error);
                alert("Ha ocurrido un error");
            });
        }
    }

    render() {
        const {pregunta, Ecuaciongeneral, Centro, Radio, x1,x2,x3,y1,y2,y3,cx,cy} = this.state;
        return (
            <Container className="MarginContainer">
                <h3>Informacion de la pregunta</h3>
                <p>Pregunta: {pregunta}</p>
                <p>Ecuacion: {Ecuaciongeneral}</p>
                <p>Centro: {Centro}</p>
                <p>Radio: {Radio}</p>
                <Button variant="secondary" onClick={() => window.location.href = "/Proyecto/"}>
                    Regresar
                </Button>
                <br></br>
                <svg width='1000' height='1000'>
                    <line x1="0" y1="500" x2="1000" y2="500" stroke="black"></line>
                    <line x1="500" y1="0" x2="500" y2="1000" stroke="black"></line>
                    {/*circulo generado*/}
                    <circle cx={500+(cx*25)} cy={500-(cy*25)} r={(Radio*25)} fill="none" stroke="black" strokeWidth="2"></circle>
                    {/*circulo centro punto*/}
                    <circle cx={500+(cx*25)} cy={500-(cy*25)} r="5" fill="red"></circle>
                    {/*circulo punto 1*/}
                    <circle cx={500+(x1*25)} cy={500-(y1*25)} r="5" fill="blue"></circle>
                    {/*circulo punto 2*/}
                    <circle cx={500+(x2*25)} cy={500-(y2*25)} r="5" fill="green"></circle>
                    {/*circulo punto 3*/}
                    <circle cx={500+(x3*25)} cy={500-(y3*25)} r="5" fill="cyan"></circle>
                </svg>
                
            </Container>
        )
    }
}

export default Info;