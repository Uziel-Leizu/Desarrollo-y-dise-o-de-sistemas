import React from "react";
import { Button } from "react-bootstrap";
import { Link } from "react-router-dom";
import axios from "axios";

const Pregunta = ({ id, pregunta }) => {

    const handleClickEliminar = (event) => {
        //Eliminar
        axios.get(`Eliminar?id=${id}`).then(response => {
        }).catch(error => {
            console.info(error);
            alert(response.data.message);
        }).finally(() => {
            window.location.href = "/Proyecto/";
        });
    }

    return (
        <tr>
            <td>{pregunta}</td>
            <td className="AlignCenter">
                <Button
                    variant="success"
                    className="M-6">
                    <Link to={`/Proyecto/info?id=${id}`} className="CustomLink" >
                        Ver pregunta
                    </Link>
                </Button>
                <Button
                    variant="primary"
                    className="M-6">
                    <Link to={`/Proyecto/probar?id=${id}`} className="CustomLink">
                        Probar
                    </Link>
                </Button>
                <Button
                    variant="warning"
                    className="M-6">
                    <Link to={`/Proyecto/formulario?id=${id}`} className="CustomLink" >
                        Editar pregunta
                    </Link>
                </Button>
                <Button
                    variant="danger"
                    className="M-6"
                    onClick={handleClickEliminar}>
                    Eliminar pregunta
                </Button>
            </td>
        </tr>
    )
}
export default Pregunta;