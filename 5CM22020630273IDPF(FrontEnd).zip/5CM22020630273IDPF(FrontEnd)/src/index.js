import React from "react";
import {
    Switch,
    Route,
} from "react-router-dom";
import Home from "./components/home";
import 'bootstrap/dist/css/bootstrap.min.css';
import "./styles/styles.css"
import Login from "./components/login"
import Info from "./components/info";
import Pregunta from "./components/pregunta";
import Formulario from "./components/formulario";
import Probar from "./components/probar";

const App = () => {
    return (
        <div>
            <Switch>
                <Route exact path="/Proyecto/">
                    <Login />
                </Route>
                <Route exact path="/Proyecto/home">
                    <Home />
                </Route>
                <Route exact path="/Proyecto/info">
                    <Info />
                </Route>
                <Route exact path="/Proyecto/pregunta">
                    <Pregunta />
                </Route>
                <Route exact path="/Proyecto/formulario">
                    <Formulario />
                </Route>
                <Route exact path="/Proyecto/probar">
                    <Probar />
                </Route>
                <Route path="*" render={() => <h1>RECURSO NO ENCONTRADO</h1>} />
            </Switch>
        </div>
    );
}
export default App;